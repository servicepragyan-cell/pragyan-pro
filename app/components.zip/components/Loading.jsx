export default function Loading() {
  return (
    <div className="fixed inset-0 z-[9999] bg-black flex flex-col items-center justify-center">
      <h1 className="text-white text-2xl tracking-widest mb-4">
        PRAGYAN
      </h1>

      <div className="w-64 h-1 bg-gray-800 rounded overflow-hidden">
        <div className="h-1 bg-amber-400 animate-pulse w-full" />
      </div>
    </div>
  );
}
