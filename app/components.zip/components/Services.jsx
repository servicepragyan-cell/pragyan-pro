"use client";

import { useRef, useLayoutEffect } from "react";
import gsap from "gsap";
import { useRouter } from "next/navigation"; // Next.js router
import { services } from "@/app/data/services";

const bubblePositions = [
  { top: "10%", left: "3%" },
  { top: "26%", left: "35%" },
  { top: "12%", left: "60%" },
  // 
  { top: "75%", left: "67%" },
  { top: "60%", left: "40%" },
  { top: "72%", left: "3%" },
  // 
  { top: "40%", left: "8%" },
  { top: "45%", left: "75%" },
];

const bubbleColors = [
  { outer: "rgba(34,197,94,0.45)", inner: "rgba(74,222,128,0.35)" },    // green
  { outer: "rgba(251,191,36,0.45)", inner: "rgba(253,230,138,0.35)" },  // amber
  { outer: "rgba(59,130,246,0.45)", inner: "rgba(147,197,253,0.35)" },  // blue
  { outer: "rgba(236,72,153,0.45)", inner: "rgba(249,168,212,0.35)" },  // pink
  { outer: "rgba(14,165,233,0.45)", inner: "rgba(125,211,252,0.35)" },  // sky
  { outer: "rgba(20,184,166,0.45)", inner: "rgba(94,234,212,0.35)" },   // teal
  { outer: "rgba(236,72,153,0.45)", inner: "rgba(249,168,212,0.35)" },   // pink
  { outer: "rgba(20,184,166,0.45)", inner: "rgba(94,234,212,0.35)" },   // teal
];

export default function Services() {
  const bubbleRef = useRef({});
  const router = useRouter();

  const blastBubble = (id, slug) => {
    const bubble = bubbleRef.current[id];
    if (!bubble) return;

    const tl = gsap.timeline();

    // Pop effect
    tl.to(bubble, { scale: 1.3, duration: 0.2, ease: "power2.out" });

    // Create particle explosion
    for (let i = 0; i < 15; i++) {
      const particle = document.createElement("span");
      particle.className = "absolute w-2 h-2 bg-white rounded-full pointer-events-none";
      bubble.appendChild(particle);

      gsap.set(particle, {
        x: 0,
        y: 0,
        xPercent: -50,
        yPercent: -50,
        left: "50%",
        top: "50%",
      });

      gsap.to(particle, {
        x: gsap.utils.random(-120, 120),
        y: gsap.utils.random(-120, 120),
        opacity: 0,
        scale: 0,
        duration: gsap.utils.random(0.6, 1.2),
        ease: "power3.out",
        onComplete: () => particle.remove(),
      });
    }

    // After animation, reset balloon scale & opacity then redirect
    tl.to(bubble, {
      scale: 0,
      opacity: 0,
      duration: 0.4,
      ease: "power3.in",
    })
      .set(bubble, { scale: 1, opacity: 1 }) // reset immediately after fade out
      .call(() => {
        router.push(`/#${slug}`);
      });
  };

  // Floating animation for bubbles
  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      Object.values(bubbleRef.current).forEach((bubble, i) => {
        if (!bubble) return;

        gsap.to(bubble, {
          x: gsap.utils.random(-30, 30),
          y: gsap.utils.random(-30, 30),
          duration: gsap.utils.random(4, 7),
          repeat: -1,
          yoyo: true,
          ease: "sine.inOut",
          delay: i * 0.2,
        });
      });
    });

    return () => ctx.revert();
  }, []);

  return (
    <section className="relative bg-black overflow-hidden mt-12 py-12 px-6 md:px-12 starField" id="services">
      <div className="max-w-6xl mx-auto text-start lg:text-center">
        <h2 className="text-4xl sm:text-5xl font-semibold mb-6 text-white">Services</h2>
        <p className="text-white tracking-widest mb-4 text-sm sm:text-base">
          <span className="text-xl text-[#FCDB66] mr-2 ">✦</span>
          Every brand is like a jigsaw puzzle; we provide the missing piece — clever ideas, sharp strategies, with campaigns that spark connections and make the brand unforgettable.
        </p>
      </div>

      <div className="relative h-125 lg:h-150">
        {services.map((service, index) => (
          <div
            key={service.id}
            ref={(el) => (bubbleRef.current[service.id] = el)}
            className={`bubble absolute rounded-full w-37.5 h-37.5 sm:w-50 sm:h-50
                       flex items-center justify-center text-white font-medium px-6 cursor-pointer transition-transform`}
            style={{
              top: bubblePositions[index].top,
              left: bubblePositions[index].left,
              background: `radial-gradient(circle at 30% 30%, ${bubbleColors[index].inner}, transparent 70%),
                           radial-gradient(circle at 70% 70%, ${bubbleColors[index].outer}, transparent 60%)`,
              boxShadow: `0 0 40px ${bubbleColors[index].outer}`,
            }}
            onClick={() => blastBubble(service.id, service.slug)}
            onMouseEnter={() =>
              gsap.to(bubbleRef.current[service.id], { scale: 1.2, duration: 0.4 })
            }
            onMouseLeave={() =>
              gsap.to(bubbleRef.current[service.id], { scale: 1, duration: 0.4 })
            }
          >
            <h3 className="text-sm sm:text-lg text-center leading-tight">{service.title}</h3>
          </div>
        ))}
      </div>
    </section>
  );
}
