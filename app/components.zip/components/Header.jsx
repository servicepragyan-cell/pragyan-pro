"use client";

import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import Link from 'next/link'
import Image from "next/image";

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showHeader, setShowHeader] = useState(true);
  const [bgBlack, setBgBlack] = useState(false);
  let lastScrollY = 0;

  useEffect(() => {
    const onScroll = () => {
      const currentScrollY = window.scrollY;

      // Hide on scroll down, show on scroll up
      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setShowHeader(false);
      } else {
        setShowHeader(true);
      }

      // Background turns black after scroll
      setBgBlack(currentScrollY > 80);
      lastScrollY = currentScrollY;
    };

    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <nav
        className={`text-white fixed top-0 left-0 right-0 z-50 px-8 py-3 flex justify-between items-center transition-all duration-500 bg-black
        ${showHeader ? "translate-y-0" : "-translate-y-full"}
        ${bgBlack ? "bg-black/80 backdrop-blur" : "bg-transparent"}`}
      >
        <Link href="/">
          <img src="/PragyanLogo.webp" alt="pragyan" className="h-16 p-1 md:p-0" />
        </Link>
        <button onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X className=" cursor-pointer" size={32} /> : <Menu className=" cursor-pointer" size={32} />}
        </button>
      </nav>

      {/* FULL SCREEN MENU */}
      <div
        className={`fixed inset-0 z-40 bg-black flex items-center justify-center transition-opacity duration-500 ${menuOpen ? "opacity-100" : "opacity-0 pointer-events-none"
          }`}
      >
        <div className="text-center space-y-10">
          {["Services", "Portfolio", "Testimonial", "Why Choose Us", "Contact Us"].map((item) => {
            const id = item.toLowerCase().replace(/\s+/g, "-");

            return (
              <a
                key={item}
                href={`#${id}`}
                onClick={() => setMenuOpen(false)}
                className="block text-3xl md:text-4xl lg:text-5xl font-medium text-white hover:text-[#FCDB66] transition"
              >
                {item}
              </a>
            );
          })}

        </div>
      </div>
    </>
  );
}
