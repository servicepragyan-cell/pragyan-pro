"use client";

import Image from "next/image";
import Link from "next/link";
import { portfolioData } from "@/app/data/portfolioData";
import { FaArrowRightLong } from "react-icons/fa6";
export default function Portfolio() {
  return (
    <section
      id="portfolio"
      className="bg-black text-white py-16 px-4 sm:px-6 md:px-12"
    >
      <div className="max-w-7xl mx-auto">

        {/* HEADER */}
        <div className="max-w-3xl mb-14">
          <p className="text-[#FCDB66] tracking-widest mb-4 text-2xl uppercase">
            <span className="text-2xl">✦</span> PORTFOLIO
          </p>

          <h2 className="text-4xl sm:text-5xl font-semibold mb-6 leading-tight">
            Stories of clarity,<br className="hidden sm:block" />
            credibility, and growth
          </h2>

          <p className="text-gray-300 leading-relaxed text-base sm:text-lg">
            Every project begins with a single question — what problem are we
            really solving? Here’s how we’ve helped brands find clarity.
          </p>
        </div>

        {/* GRID */}
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {portfolioData.map((item) => (
            <Link
              key={item.id}
              href={`/portfolio/${item.slug}`}
              className="group relative rounded-2xl border border-white/20 bg-white/10 backdrop-blur-sm overflow-hidden transition-all duration-300 hover:border-[#FCDB66]/60 hover:-translate-y-1"
            >
              {/* IMAGE */}
              <div className="relative h-55 overflow-hidden">
                <Image
                  src={item.image}
                  alt={item.title}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />

                {/* Overlay */}
                <div className="absolute inset-0 bg-linear-to-t from-black/70 via-black/20 to-transparent" />
              </div>

              {/* CONTENT */}
              <div className="p-6 flex flex-col h-full">
                <h3 className="text-xl font-semibold mb-2 group-hover:text-[#FCDB66] transition">
                  {item.title}
                </h3>

                <p className="text-xl text-gray-300 mb-4 leading-relaxed">
                  {item.subtitle}
                </p>
                <span className="text-[#FCDB66] hover:text-white flex items-center gap-3">Read More<FaArrowRightLong /></span>

                {/* CTA */}
                <span className="mt-auto inline-flex items-center gap-2 text-sm font-medium text-[#FCDB66]">
                  View case study
                  <svg
                    className="w-4 h-4 transition-transform group-hover:translate-x-1"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                  </svg>
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
