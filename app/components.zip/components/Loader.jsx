// "use client"

// function Loader() {

//     const [progress, setProgress] = useState(0);

//     useEffect(() => {

//         const interval = setInterval(() => {

//             setProgress((p) => {

//                 if (p >= 100) {

//                     clearInterval(interval);
//                     // 
//                     return 100;

//                 }

//                 return p + 2;

//             })


//         }, 30);

//         return () => clearInterval(interval);

//     }, [])


//     return (
//         <>
//             <div className=" fixed inset-0 z-[9999] bg-black flex flex-col justify-center items-center" >
//                 <h1>PRAGYAN</h1>

//                 <div className=" max-w-64 h-1 bg-gray-800 rounded overflow-hidden " >
//                     <div className=" h-1 bg-amber-400 transition-all duration-300" style={{ width : `${progress}%` }}  >
//                     </div>
//                 </div>

//             </div>
//         </>
//     )
// }

// export default Loader
