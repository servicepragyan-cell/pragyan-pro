"use client";

import { useEffect, useState } from "react";
import Image from "next/image";

export default function AppLoader({ children }) {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      {loading && (
        <div className="fixed inset-0 z-9999 flex items-center justify-center bg-black">
          <div className="flex flex-col items-center gap-4">
            {/* <div className="w-12 h-12 border-4 border-[#FCDB66] border-t-transparent rounded-full animate-spin" /> */}
            <Image src="/MarketingPortfolio.webp" width={48} height={48} alt="Loading" className="animate-spin" />
            <p className="text-[#FCDB66] text-sm tracking-widest">
              LOADING...
            </p>
          </div>
        </div>
      )}

      <div
        className={`transition-opacity duration-500 ${loading ? "opacity-0" : "opacity-100"
          }`}
      >
        {children}
      </div>
    </>
  );
}
