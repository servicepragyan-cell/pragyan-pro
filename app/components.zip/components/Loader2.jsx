"use client"

import { useEffect, useState } from 'react'

function Loader2({ children }) {

    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const hideLoader = () => setLoading(false);

        if (document.readyState === "complete") {
            hideLoader();
        } else {
            window.addEventListener("load", hideLoader);
            return () => window.removeEventListener("load", hideLoader);
        }
    }, []);

    return (
        <>
            {loading && (
                <div className="fixed inset-0 z-[9999] bg-black flex flex-col items-center justify-center">
                    <h1 className="text-white text-2xl tracking-widest mb-4">
                        PRAGYAN
                    </h1>

                    <div className="w-64 h-1 bg-gray-800 rounded overflow-hidden">
                        <div className="h-1 bg-amber-400 animate-pulse w-full" />
                    </div>
                </div>
            )}

            <div className={loading ? "opacity-0" : "opacity-100"}>
                {children}
            </div>
        </>
    )
}

export default Loader2
