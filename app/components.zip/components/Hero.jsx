"use client";

import { useRef, useEffect } from "react";
import gsap from "gsap";
import RotatingBadge from "@/app/components/RotatingBadge";

export default function Hero() {
  const textRef = useRef(null);
  // const highlightRef = useRef(null);

  useEffect(() => {
    // Animate each line with stagger + scale + fade
    gsap.fromTo(
      textRef.current.children,
      { y: 60, opacity: 0, scale: 0.8 },
      {
        y: 0,
        opacity: 1,
        scale: 1,
        duration: 1.2,
        ease: "power3.out",
        stagger: 0.25,
      }
    );

    // Optional: You can re-enable pulsing highlight if desired
    // gsap.to(highlightRef.current, {
    //   color: "#facc15",
    //   textShadow: "0 0 10px #facc15",
    //   repeat: -1,
    //   yoyo: true,
    //   ease: "sine.inOut",
    //   duration: 2,
    // });
  }, []);

  return (
    <section className="relative flex items-center my-12 md:my-16 lg:mt-20 md:h-screen">
      {/* Video Background */}
      {/* <video
        className="absolute inset-0 w-full h-full object-cover brightness-75 mix-blend-overlay"
        src="/banner-video.mov"
        autoPlay
        muted
        loop
        playsInline
      /> */}

      {/* Content Container */}
      <div className=" relative z-20 max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-12 items-center text-white select-none  ">
        <div ref={textRef} className="font-[Plus Jakarta Sans] mt-100 md:mt-130 lg:mt-0 space-y-6 text-center lg:text-left ">
          <h1 className="flex text-4xl md:text-5xl lg:text-7xl font-bold ">

            Connecting
            <span className="text-[#FCDB66] font-bold"> People</span>,

          </h1>
          <h1 className="flex text-4xl md:text-5xl lg:text-7xl font-bold">
            Building
            <span className="text-[#FCDB66] font-bold">Brands</span>,
          </h1>
          <h1 className="flex text-4xl md:text-5xl lg:text-7xl font-bold">
            Driving
            <span className="text-[#FCDB66] font-bold">Results.</span>
          </h1>

          <p className="text-start  mt-8 max-w-xl mx-auto lg:mx-0 text-lg md:text-2xl font-medium text-gray-300 leading-relaxed">
            At <span className="font-semibold text-[#FCDB66] ml-1">Pragyan Marketing</span>, we
            combine expertise and integrity to make your business visible, credible, and unstoppable.
          </p>

          {/* CTA */}
          <div className="my-4 mt-8 md:mt-12 flex justify-start">
            <a href="#contact" className="px-10 py-4 bg-[#FCDB66] text-black text-xl rounded-full font-semibold shadow-xl shadow-yellow-400/40 hover:scale-105 transition-transform duration-300 flex items-center gap-4">
              Start a project
              {/* <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-7 w-7"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2}
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
              </svg> */}
            </a>
          </div>
        </div>

        {/* Right Side - Jumping Image */}
        <div className=" lg:opacity-[1] md:flex justify-center items-center -mt-330 md:-mt-400 lg:mt-0 -z-1 ">
          <video
            className="w-100 sm:w-80 md:w-110 "
            src="/video1.mp4"
            autoPlay
            muted
            loop
            playsInline
          />
        </div>

      </div>

      {/* Rotating Badge */}
      <div className="absolute hidden lg:block bottom-10 right-10 z-30">
        <RotatingBadge />
      </div>

      {/* Custom Jumping Animation */}
      <style jsx>{`
        @keyframes jump-slow {
          0%, 100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-30px);
          }
        }

        .jump-slow {
          animation: jump-slow 6s ease-in-out infinite;
          will-change: transform;
        }
      `}</style>
    </section>
  );
}