import React from "react";

function AboutUs() {
  return (
    <>
      {/* About Us */}
      <section id="about-us" className="bg-black py-16 px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          {/* Section Label */}
          <div className="flex items-center mb-4 lg:justify-start gap-2 text-2xl text-[#FCDB66] ">
            <span className="text-2xl">✦</span>ABOUT US
          </div>

          {/* Main Heading */}
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-semibold leading-tight mb-8 text-white ">
            FlowPragyan is where brands come to think bigger.
          </h2>

          {/* Intro Paragraph */}
          <p className="text-lg md:text-xl text-gray-300 leading-relaxed mb-12">
            We are a hub of curious minds, restless creators, and problem-solvers,
            constantly looking for ways to push brands beyond the obvious. Our
            team operates like a finely tuned neural network — every connection
            matters.
          </p>

          {/* Core Content */}
          <div className="space-y-6 md:space-y-10 text-lg md:text-xl text-gray-300 leading-relaxed ">
            <p>
              We collaborate across design, content, digital, and experiential
              work, debating and refining ideas until they achieve maximum
              impact. Like a brain firing at full potential, we explore
              questions, test possibilities, and turn challenges into
              opportunities.
            </p>

            <p>
              We believe every brand has a unique identity, and it’s our job to
              help it shine in ways that matter. Our focus is on clarity in
              communication, intelligence in execution, and creativity that
              leaves a lasting impression.
            </p>

            <p>
              Each project is approached thoughtfully, ensuring ideas are not
              just seen, but felt and remembered.
            </p>
          </div>

          {/* Vision & Mission */}
          <div className="grid md:grid-cols-2 gap-12 mt-10 md:mt-16">
            <div>
              <h3 className="text-2xl md:text-3xl text-[#FCDB66] font-semibold mb-4">
                Vision
              </h3>
              <p className="text-lg md:text-xl text-gray-300 leading-relaxed">
                To be the most trusted marketing partner for brands seeking
                clarity, creativity, and results.
              </p>
            </div>

            <div>
              <h3 className="text-2xl md:text-3xl text-[#FCDB66] font-semibold mb-4">
                Mission
              </h3>
              <p className="text-lg md:text-xl text-gray-300 leading-relaxed">
                To deliver innovative, data-driven marketing strategies that
                help brands grow, connect, and thrive.
              </p>
            </div>
          </div>

          {/* Brand Statement */}
          <p className="text-xl md:text-2xl font-light text-gray-200 mt-8 pt-6 md:mt-12 md:pt-12 border-t border-gray-800 leading-relaxed ">
            <span className="bg-gradient-to-r from-amber-300  to-[#FCDB66] bg-clip-text text-transparent font-semibold">
              Pragyan
            </span>{" "}
            is the brain your brand has been looking for. We don’t just make
            campaigns — we craft experiences that elevate your brand, connect
            with audiences, and build a presence that endures. With us, your
            brand becomes smarter, stronger, and unforgettable.
          </p>
        </div>
      </section>
    </>
  );
}

export default AboutUs;
